(function() {
  "use strict";
  const inputEl = document.getElementById(
    "service-input"
  );
  const editBtn = document.getElementById("edit-btn");
  const actionsEl = document.getElementById("actions");
  const saveBtn = document.getElementById("save-btn");
  const cancelBtn = document.getElementById(
    "cancel-btn"
  );
  const errorEl = document.getElementById(
    "error-message"
  );
  if (!inputEl || !editBtn || !actionsEl || !saveBtn || !cancelBtn || !errorEl) {
    console.error("Required DOM elements not found");
  } else {
    let preServiceUrl = "";
    const showError = function(msg) {
      if (!errorEl) return;
      if (!msg) {
        errorEl.style.display = "none";
        errorEl.textContent = "";
        return;
      }
      errorEl.style.display = "block";
      errorEl.textContent = msg;
    };
    const setDisabled = function(disabled) {
      if (!inputEl || !editBtn || !actionsEl) return;
      inputEl.disabled = disabled;
      editBtn.style.display = disabled ? "inline-block" : "none";
      actionsEl.style.display = disabled ? "none" : "flex";
    };
    (function initFromQuery() {
      try {
        const search = window.location.search || "";
        if (!search) return;
        const params = new URLSearchParams(search);
        const serviceUrl = params.get("serviceUrl") || "";
        if (serviceUrl) {
          inputEl.value = serviceUrl;
          preServiceUrl = serviceUrl;
        }
      } catch (e) {
      }
    })();
    editBtn.addEventListener("click", () => {
      setDisabled(false);
      showError("");
    });
    cancelBtn.addEventListener("click", () => {
      inputEl.value = preServiceUrl;
      setDisabled(true);
      showError("");
    });
    const normalizeUrl = function(url) {
      try {
        const info = new URL(url);
        if (info.origin === "null") {
          return null;
        }
        return `${info.origin}/`;
      } catch (e) {
        return null;
      }
    };
    saveBtn.addEventListener("click", () => {
      const raw = (inputEl.value || "").trim();
      if (!raw) {
        showError("请配置服务器地址");
        return;
      }
      const finalUrl = normalizeUrl(raw);
      if (!finalUrl) {
        showError("服务器地址无效，请检查是否正确");
        return;
      }
      showError("");
      setDisabled(true);
      const postMessage = window.postMessage;
      if (postMessage) {
        postMessage(
          "messageFromWebview",
          {
            pluginMessage: {
              type: "saveServiceUrl",
              data: {
                serviceUrl: finalUrl
              }
            }
          },
          "*"
        );
      }
    });
  }
})();
